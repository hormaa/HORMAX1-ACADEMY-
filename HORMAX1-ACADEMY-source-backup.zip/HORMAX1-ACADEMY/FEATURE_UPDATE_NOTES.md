# LearnSoo feature update

- `/admin` provides an auth-gated admin dashboard for course metadata, lesson titles, quiz questions, publishing status, and local draft persistence.
- Certificate issuance now persists certificate records when the database is available and calls Resend when `RESEND_API_KEY`, `EMAIL_FROM`, and `APP_URL` are configured.
- Student progress is saved locally for preview users and persisted to `studentProgress` for authenticated Manus users.
- The certificate visual template is already complete; only real email delivery configuration is pending.
- `pnpm check` and `pnpm build` passed after the update.

## Brand and verification QA

The visible platform branding now reads HORMAX1 ACADEMY across the homepage, footer, certificate page, admin label, verification page, metadata, and email subject. The public verification route is `/verify`; it accepts a Certificate ID and shows a verified record when a persisted certificate exists, or a clear not-found state for invalid IDs. A real older demo ID was not found because it was issued before database certificate persistence was added; newly issued certificates will be persisted for verification.
