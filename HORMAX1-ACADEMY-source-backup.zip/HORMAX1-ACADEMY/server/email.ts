type CertificateEmail = {
  studentName: string;
  studentEmail: string;
  courseTitle: string;
  certificateId: string;
  score: number;
};

export async function sendCertificateEmail(input: CertificateEmail) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  const appUrl = process.env.APP_URL ?? "http://localhost:3000";
  if (!apiKey || !from) return { status: "not_configured" as const };

  const certificateUrl = `${appUrl}/certificate/${input.certificateId}`;
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: [input.studentEmail],
      subject: `Certificate-kaaga HORMAX1 ACADEMY — ${input.courseTitle}`,
      html: `<div style="font-family:Arial,sans-serif;line-height:1.6;color:#173f35"><h2>Hambalyo ${input.studentName}!</h2><p>Waxaad si guul leh u dhammaysay <strong>${input.courseTitle}</strong> adigoo helay score ${input.score}%.</p><p><a href="${certificateUrl}" style="background:#173f35;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none">Daawo certificate-kaaga</a></p><p>Certificate ID: ${input.certificateId}</p></div>`,
    }),
  });
  if (!response.ok) return { status: "failed" as const, detail: await response.text() };
  return { status: "sent" as const };
}
