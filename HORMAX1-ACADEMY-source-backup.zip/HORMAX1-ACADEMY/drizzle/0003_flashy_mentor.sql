CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`message` text NOT NULL,
	`read` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paymentMethods` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`merchantNumber` varchar(100) NOT NULL,
	`accountName` varchar(180) NOT NULL,
	`instructions` text NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paymentMethods_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseSlug` varchar(120) NOT NULL,
	`courseTitle` varchar(180) NOT NULL,
	`coursePriceCents` int NOT NULL,
	`amountPaidCents` int NOT NULL,
	`fullName` varchar(180) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`email` varchar(320) NOT NULL,
	`transactionRef` varchar(120) NOT NULL,
	`paymentMethod` varchar(100) NOT NULL,
	`receiptUrl` text,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`rejectionReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `courses` ADD `priceCents` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `isPaid` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `active` int DEFAULT 1 NOT NULL;