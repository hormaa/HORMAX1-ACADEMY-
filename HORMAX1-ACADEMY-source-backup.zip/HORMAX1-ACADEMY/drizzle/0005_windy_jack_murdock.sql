CREATE TABLE `courseModules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`position` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `courseModules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `courseQuizzes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`moduleId` int,
	`title` varchar(180) NOT NULL,
	`passingScore` int NOT NULL DEFAULT 70,
	`attempts` int NOT NULL DEFAULT 3,
	`isFinal` int NOT NULL DEFAULT 0,
	`published` int NOT NULL DEFAULT 0,
	CONSTRAINT `courseQuizzes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quizQuestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`quizId` int NOT NULL,
	`type` enum('multiple_choice','true_false','multiple_answers') NOT NULL DEFAULT 'multiple_choice',
	`question` text NOT NULL,
	`answers` text NOT NULL,
	`correctAnswer` text NOT NULL,
	`explanation` text,
	`points` int NOT NULL DEFAULT 1,
	`position` int NOT NULL DEFAULT 0,
	CONSTRAINT `quizQuestions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `courses` ADD `published` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `instructor` varchar(180) DEFAULT 'HORMAX ACADEMY' NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `thumbnailUrl` text;--> statement-breakpoint
ALTER TABLE `courses` ADD `certificateEligible` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `sortOrder` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE `lessons` ADD `moduleId` int;--> statement-breakpoint
ALTER TABLE `lessons` ADD `videoUrl` text;--> statement-breakpoint
ALTER TABLE `lessons` ADD `resourceUrl` text;--> statement-breakpoint
ALTER TABLE `lessons` ADD `freePreview` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `lessons` ADD `required` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `lessons` ADD `published` int DEFAULT 0 NOT NULL;