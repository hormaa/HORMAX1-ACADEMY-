import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "student", "admin", "super_admin"]).default("student").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  level: varchar("level", { length: 40 }).notNull(),
  duration: varchar("duration", { length: 40 }).notNull(),
  lessonCount: int("lessonCount").notNull(),
  priceCents: int("priceCents").default(0).notNull(),
  isPaid: int("isPaid").default(0).notNull(),
  active: int("active").default(1).notNull(),
  published: int("published").default(0).notNull(),
  instructor: varchar("instructor", { length: 180 }).default("HORMAX ACADEMY").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  certificateEligible: int("certificateEligible").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  color: varchar("color", { length: 32 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const courseModules = mysqlTable("courseModules", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  position: int("position").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const lessons = mysqlTable("lessons", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  moduleId: int("moduleId"),
  position: int("position").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  summary: text("summary").notNull(),
  body: text("body").notNull(),
  duration: varchar("duration", { length: 40 }).notNull(),
  videoUrl: text("videoUrl"),
  resourceUrl: text("resourceUrl"),
  freePreview: int("freePreview").default(0).notNull(),
  required: int("required").default(1).notNull(),
  published: int("published").default(0).notNull(),
});

export const courseQuizzes = mysqlTable("courseQuizzes", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  moduleId: int("moduleId"),
  title: varchar("title", { length: 180 }).notNull(),
  passingScore: int("passingScore").default(70).notNull(),
  attempts: int("attempts").default(3).notNull(),
  isFinal: int("isFinal").default(0).notNull(),
  published: int("published").default(0).notNull(),
});

export const quizQuestions = mysqlTable("quizQuestions", {
  id: int("id").autoincrement().primaryKey(),
  quizId: int("quizId").notNull(),
  type: mysqlEnum("type", ["multiple_choice", "true_false", "multiple_answers"]).default("multiple_choice").notNull(),
  question: text("question").notNull(),
  answers: text("answers").notNull(),
  correctAnswer: text("correctAnswer").notNull(),
  explanation: text("explanation"),
  points: int("points").default(1).notNull(),
  position: int("position").default(0).notNull(),
});

export const enrollments = mysqlTable("enrollments", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), courseId: int("courseId").notNull(), courseSlug: varchar("courseSlug", { length: 120 }).notNull(), progress: int("progress").default(0).notNull(), completedAt: timestamp("completedAt"), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const certificates = mysqlTable("certificates", {
  id: int("id").autoincrement().primaryKey(), certificateId: varchar("certificateId", { length: 40 }).notNull().unique(), studentName: varchar("studentName", { length: 180 }).notNull(), studentEmail: varchar("studentEmail", { length: 320 }).notNull(), courseSlug: varchar("courseSlug", { length: 120 }).notNull(), courseTitle: varchar("courseTitle", { length: 180 }).notNull(), score: int("score").notNull(), issuedAt: timestamp("issuedAt").defaultNow().notNull(),
});

export const lessonProgress = mysqlTable("lessonProgress", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), lessonId: int("lessonId").notNull(), completed: int("completed").default(0).notNull(), completedAt: timestamp("completedAt"),
});

export const studentProgress = mysqlTable("studentProgress", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), courseSlug: varchar("courseSlug", { length: 120 }).notNull(), progress: int("progress").default(0).notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const paymentMethods = mysqlTable("paymentMethods", {
  id: int("id").autoincrement().primaryKey(), name: varchar("name", { length: 100 }).notNull(), merchantNumber: varchar("merchantNumber", { length: 100 }).notNull(), accountName: varchar("accountName", { length: 180 }).notNull(), instructions: text("instructions").notNull(), active: int("active").default(1).notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), courseSlug: varchar("courseSlug", { length: 120 }).notNull(), courseTitle: varchar("courseTitle", { length: 180 }).notNull(), coursePriceCents: int("coursePriceCents").notNull(), amountPaidCents: int("amountPaidCents").notNull(), fullName: varchar("fullName", { length: 180 }).notNull(), phone: varchar("phone", { length: 40 }).notNull(), email: varchar("email", { length: 320 }).notNull(), transactionRef: varchar("transactionRef", { length: 120 }).notNull(), paymentMethod: varchar("paymentMethod", { length: 100 }).notNull(), receiptUrl: text("receiptUrl"), status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(), reviewedBy: int("reviewedBy"), reviewedAt: timestamp("reviewedAt"), rejectionReason: text("rejectionReason"), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), title: varchar("title", { length: 180 }).notNull(), message: text("message").notNull(), read: int("read").default(0).notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Course = typeof courses.$inferSelect;
export type Lesson = typeof lessons.$inferSelect;
export type Certificate = typeof certificates.$inferSelect;
