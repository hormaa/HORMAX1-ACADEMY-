CREATE TABLE `certificates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`certificateId` varchar(40) NOT NULL,
	`studentName` varchar(180) NOT NULL,
	`studentEmail` varchar(320) NOT NULL,
	`courseSlug` varchar(120) NOT NULL,
	`courseTitle` varchar(180) NOT NULL,
	`score` int NOT NULL,
	`issuedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `certificates_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificates_certificateId_unique` UNIQUE(`certificateId`)
);
--> statement-breakpoint
CREATE TABLE `courses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`category` varchar(80) NOT NULL,
	`level` varchar(40) NOT NULL,
	`duration` varchar(40) NOT NULL,
	`lessonCount` int NOT NULL,
	`color` varchar(32) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `courses_id` PRIMARY KEY(`id`),
	CONSTRAINT `courses_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `enrollments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`progress` int NOT NULL DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `enrollments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lessonProgress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`lessonId` int NOT NULL,
	`completed` int NOT NULL DEFAULT 0,
	`completedAt` timestamp,
	CONSTRAINT `lessonProgress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lessons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`position` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`summary` text NOT NULL,
	`body` text NOT NULL,
	`duration` varchar(40) NOT NULL,
	CONSTRAINT `lessons_id` PRIMARY KEY(`id`)
);
