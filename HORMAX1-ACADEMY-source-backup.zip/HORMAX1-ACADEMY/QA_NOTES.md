# LearnSoo visual QA

## Desktop
The full landing page renders cleanly at 1280x900. The hero has a clear Somali-first message, readable contrast, a strong CTA, and the learning dashboard mockup supports the product promise. Course cards align in a three-column grid, the dark how-it-works section has good contrast, and the footer remains balanced.

## Mobile
The 390px view is responsive. The navigation collapses to a menu icon, the hero stacks correctly, the dashboard mockup scales without clipping, course cards become a single column, and the dark section keeps readable spacing. No horizontal overflow was visible.

## Functional scope verified in code
The learning workspace includes registration with full name/email, sequential lessons, a final quiz, automatic certificate issuance via tRPC with a local fallback for preview, a certificate route, and print/download support. Email delivery is prepared as an email-ready link status and requires a verified email sender/provider to become a real outbound email integration.

## Browser interaction QA
The live preview was opened in the browser. Clicking the first course opens the Learning Studio. The registration form accepted `Ayaan Cabdi` and `ayaan@example.com`, and submitting it opened Lesson 1/6 with the progress sidebar and next-lesson CTA. The flow is interactive and scrolls to the workspace as intended.
Two sequential Next buttons were tested in the browser. Lesson 2 and Lesson 3 opened correctly, the sidebar marked previous lessons complete, and progress advanced from 0% to 14% to 29%.
Lessons 4 and 5 also opened correctly through the same CTA, with progress reaching 43% and 57% and completed checkmarks appearing in the sidebar.
Lesson 6 and the final quiz opened correctly. The sidebar showed 86% before the quiz and the four answer choices plus the disabled completion CTA rendered as expected.
Selecting the correct answer and completing the quiz produced the success state for Ayaan Cabdi with a 96% score, a ready certificate CTA, and an email-ready link label. This verifies the core learner-to-certificate flow in the live preview.
The generated certificate route opened at `/certificate/LS-YRR0BFEF0C` and rendered Ayaan Cabdi's name, course title, issue date, certificate ID, and Download / Print button correctly.
