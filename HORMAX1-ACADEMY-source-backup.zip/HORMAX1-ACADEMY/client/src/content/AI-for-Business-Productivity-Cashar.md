# Cashar: AI for Business & Productivity
### (Artificial Intelligence oo loo isticmaalo Ganacsiga iyo Wax-soo-saarka)

---

## Sharaxaad Guud

Tignoolajiyada AI (Artificial Intelligence) waxay maanta noqotay mid muhiim u ah ganacsatada, shirkadaha, iyo shaqaalaha si kasta oo ay u kala duwan yihiin. Casharkan waxaad ku baran doontaa sida AI loo isticmaali karo si loo kordhiyo wax-soo-saarka (productivity), loo hagaajiyo go'aan-qaadashada, iyo loo yareeyo waqtiga shaqada.

---

## Bartilmaameedka Casharka (Learning Objectives)

Marka aad casharkan dhammayso, waxaad awoodi doontaa:

1. Inaad fahanto waxa AI yahay iyo sida loo isticmaalo ganacsiga.
2. Inaad aqoonsato qaybaha ugu muhiimsan ee AI ee ganacsiga (marketing, customer service, data analysis, iwm).
3. Inaad isticmaasho tools-ka AI ee caanka ah (ChatGPT, Canva AI, Notion AI, iwm).
4. Inaad ku dabaqdo AI si aad shaqadaada maalinlaha ah ugu dhaqso oo ugu tayo sarraysid.
5. Inaad gudato imtixaan (quiz) si aad u hesho certificate.

---

## Qaybta 1: Waa Maxay AI?

**Artificial Intelligence (AI)** waa tignoolajiyad u oggolaanaysa kombiyuutarrada inay qabtaan shaqooyin caadi ahaan u baahan maskaxda bini'aadamka — sida fahamka luqadda, go'aan-qaadashada, iyo aqoonsiga qaababka (patterns).

**Tusaale:** Marka aad weydiiso ChatGPT su'aal, wuxuu si degdeg ah kuugu jawaabaa isagoo isticmaalaya xog badan oo la baray (trained data).

---

## Qaybta 2: Sidee AI u Taageertaa Ganacsiga?

### 2.1 Marketing iyo Advertising
- AI waxay ku caawin kartaa abuurista **content** (qoraal, sawir, video ideas) si degdeg ah.
- **Tusaale:** Adigoo isticmaalaya ChatGPT, waxaad qori kartaa: *"Ii qor 5 fikrado ah post Instagram ah oo ku saabsan iibinta dharka."*

### 2.2 Adeegga Macaamiisha (Customer Service)
- Chatbots-ka AI (sida ChatGPT ama Intercom AI) ayaa ka jawaabi kara su'aalaha macaamiisha 24/7.
- **Tusaale:** Website ganacsi ayaa isticmaali kara chatbot si uu si otomaatig ah ugu jawaabo su'aalaha caadiga ah.

### 2.3 Falanqaynta Xogta (Data Analysis)
- AI waxay awoodaa inay falanqayso xog badan oo degdeg ah, taasoo ka caawinaysa shirkadaha inay go'aamo fiican qaataan.
- **Tusaale:** Isticmaalka Excel AI ama Google Sheets AI si loo helo isbeddellada iibka bishii hore.

### 2.4 Wax-soo-saarka Shakhsi ahaan (Personal Productivity)
- Tools sida **Notion AI** ama **Microsoft Copilot** waxay kaa caawin karaan qorista emails, warbixino, iyo jadwal-maareynta.
- **Tusaale:** "AI, ii samee jadwal shaqo oo toddobaad ah oo ku salaysan meetings-ka aan haysto."

### 2.5 Naqshadaynta (Design)
- Canva AI ama Adobe Firefly waxay ku caawin karaan abuurista logo, poster, iyo sawirro ganacsi.

---

## Qaybta 3: Tools-ka AI ee Ugu Caansan (2026)

| Tool | Isticmaalka |
|---|---|
| ChatGPT / Claude | Qoraal, falanqayn, go'aan-qaadasho |
| Canva AI | Naqshadaynta sawirrada iyo marketing materials |
| Notion AI | Maaraynta mashaariicda iyo qoraalka |
| Grammarly AI | Hagaajinta qoraalka Ingiriisiga |
| Zapier AI | Isku-xirka apps-ka si otomaatig ah loo shaqeeyo |

---

## Qaybta 4: Talooyin Muhiim ah (Practical Tips)

1. **Bilow yar yar:** Ha isku dayin inaad wax walba isla markiiba AI ku beddesho — bilow hal shaqo.
2. **Hubi natiijada:** AI mar mar khalad ayay samayn kartaa — had iyo jeer hubi xogta muhiimka ah.
3. **Isticmaal prompts cad:** Su'aasha ama amarka aad AI siiso, ha ahaado mid cad oo faahfaahsan si aad natiijo fiican u hesho.
4. **Baro si joogto ah:** Tignoolajiyadu si degdeg ah ayay isu bedbeddeshaa — had iyo jeer baro tools cusub.

---

## Qaybta 5: Gabagabo (Summary)

AI maaha mid beddelaya bini'aadamka, laakiin waa aalad (tool) kaa caawisa inaad si dhaqso ah oo tayo sare leh u qabato shaqadaada. Ganacsiyada iyo shaqaalaha isticmaala AI si sax ah ayaa heli doona faa'iido tartan (competitive advantage) oo weyn.

---

## Imtixaanka (Quiz) — 20 Su'aalood

*Fadlan dooro jawaabta ugu saxsan.*

**1.** AI waxaa loola jeedaa:
A) Computer hardware oo keliya
B) Tignoolajiyad u oggolaanaysa kombiyuutarrada inay qabtaan shaqooyin maskaxeed
C) Barnaamij games ah oo keliya
D) Wax aan la isticmaali karin ganacsiga

**2.** ChatGPT waa tusaale ka mid ah:
A) Hardware
B) AI Chatbot/Assistant
C) Camera
D) Printer

**3.** AI-ga marketing-ka waxaa loo isticmaali karaa:
A) In lagu abuuro content sida qoraalka iyo sawirrada
B) In lagu daaweeyo bukaanka oo keliya
C) In lagu kabo baabuur
D) Midna kuma jiro

**4.** Chatbot-ku muxuu u adeegaa ganacsiga?
A) Wuxuu jawaabaa su'aalaha macaamiisha si otomaatig ah
B) Wuxuu iibiya alaabta si toos ah
C) Wuxuu qaataa lacagta bangiga
D) Midna kuma jiro

**5.** Notion AI waxaa loo isticmaalaa:
A) Naqshadaynta baabuurta
B) Maaraynta mashaariicda iyo qoraalka
C) Cunista cuntada
D) Dhismaha guryaha

**6.** Canva AI waxay ku caawisaa:
A) Naqshadaynta sawirrada iyo marketing materials
B) Falanqaynta lacagta bangiga
C) Xisaabinta canshuuraha
D) Wax ka mid ah kuma jiro

**7.** Waa maxay faa'iidada ugu weyn ee AI ee ganacsiga?
A) Kordhinta wax-soo-saarka iyo dhaqsaha
B) Yareynta shaqaalaha oo dhan
C) In lacag la kharashtaro oo keliya
D) Midna kuma jiro

**8.** Grammarly AI waxay ku caawisaa:
A) Hagaajinta qoraalka Ingiriisiga
B) Naqshadaynta website
C) Xisaabinta lacagta
D) Wax ka mid ah kuma jiro

**9.** Sidee loo hubiyaa in AI-gu sax yahay?
A) Waa in aan la hubin, had iyo jeer waa sax
B) Waa in la hubiyaa xogta muhiimka ah
C) Ma jirto habka lagu hubiyo
D) Midna kuma jiro

**10.** Zapier AI waxay ku caawisaa:
A) Isku-xirka apps-ka si otomaatig ah loo shaqeeyo
B) Cunista cuntada
C) Dhismaha guryaha
D) Wax ka mid ah kuma jiro

**11.** Data Analysis ee AI waxay ka caawisaa shirkadaha:
A) In go'aan fiican la qaato
B) In alaabta la iibiyo si toos ah
C) In shaqaalaha la eryo
D) Midna kuma jiro

**12.** Prompt wanaagsan oo AI la siiyo waa mid:
A) Aan cad ahayn
B) Cad, gaaban, oo faahfaahsan
C) Aad u dheer oo aan la fahmi karin
D) Midna kuma jiro

**13.** Microsoft Copilot waxaa loo isticmaalaa:
A) Qorista emails iyo jadwal-maareynta
B) Naqshadaynta baabuurta
C) Cunista cuntada
D) Wax ka mid ah kuma jiro

**14.** Waa maxay khatarta suurtagalka ah ee AI?
A) Wuxuu had iyo jeer sax yahay
B) Wuxuu mar mar khalad samayn karaa
C) Ma jirto khatar
D) Midna kuma jiro

**15.** Sidee loo bilaabaa isticmaalka AI ganacsiga?
A) Bilow shaqooyin badan isla mar keliya
B) Bilow yar yar, hal shaqo mar
C) Ha isticmaalin AI weligaa
D) Midna kuma jiro

**16.** AI-ga waxaa lagu isticmaali karaa naqshadaynta si loo sameeyo:
A) Logo iyo poster
B) Cuntada
C) Dharka oo keliya
D) Wax ka mid ah kuma jiro

**17.** Sababta loo baahan yahay in la sii bartoo AI waa:
A) Tignoolajiyadu had iyo jeer way is-beddeshaa
B) AI marnaba isma beddesho
C) Uma baahna in la barto
D) Midna kuma jiro

**18.** Falanqaynta xogta AI-gu waxay ku caawisaa shirkadaha:
A) In ay ogaadaan isbeddelada iibka
B) In ay dhisaan guryo
C) In ay kabaan baabuurta
D) Midna kuma jiro

**19.** Waa maxay ujeedka ugu weyn ee casharkan?
A) In la baro sida AI loo isticmaalo ganacsiga iyo wax-soo-saarka
B) In la baro dhismaha
C) In la baro cunto-kariska
D) Midna kuma jiro

**20.** AI-gu ma bedelayaa dhammaan bini'aadamka shaqada?
A) Haa, wuu bedelayaa dhammaan
B) Maya, waa aalad caawinaysa bini'aadamka
C) Ma jiro jawaab sax ah
D) Midna kuma jiro

---

## Jawaabaha Saxda ah (Answer Key)

1-B, 2-B, 3-A, 4-A, 5-B, 6-A, 7-A, 8-A, 9-B, 10-A, 11-A, 12-B, 13-A, 14-B, 15-B, 16-A, 17-A, 18-A, 19-A, 20-B

---

## Shuruudaha Certificate-ka

- Ardaygu waa inuu ka gudbaa ugu yaraan **70% (14/20)** su'aalaha si uu u helo **Certificate of Completion**.
- Certificate-ka wuxuu ka kooban yahay: Magaca ardayga, Cinwaanka casharka ("AI for Business & Productivity"), Taariikhda, iyo Calaamadda la helay.

---

*Casharkan waxaa loogu talagalay in lagu daabaco website learning ah. Waad ku dari kartaa quiz-ka interactive si otomaatig ah loo xisaabiyo natiijada iyo in la soo saaro certificate PDF ah marka la gudbo.*
