import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home, { CertificatePage } from "./pages/Home";
import Admin from "./pages/Admin";
import Verify from "./pages/Verify";
import Payments from "./pages/Payments";
import PaymentsAdmin from "./pages/PaymentsAdmin";
import PricingAdmin from "./pages/PricingAdmin";
import StudentDashboard from "./pages/StudentDashboard";
import AIBusinessQuiz from "./pages/AIBusinessQuiz";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/certificate/:id" component={CertificatePage} />
    <Route path="/admin" component={Admin} />
    <Route path="/verify" component={Verify} />
    <Route path="/payments" component={Payments} />
    <Route path="/admin/payments" component={PaymentsAdmin} />
    <Route path="/admin/pricing" component={PricingAdmin} />
    <Route path="/dashboard" component={StudentDashboard} />
    <Route path="/ai-business-quiz" component={AIBusinessQuiz} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ErrorBoundary>
    <ThemeProvider defaultTheme="light">
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </ThemeProvider>
  </ErrorBoundary>;
}

export default App;
