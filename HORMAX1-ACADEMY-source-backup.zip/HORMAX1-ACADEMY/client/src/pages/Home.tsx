import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { ArrowRight, Award, BarChart3, BookOpen, Check, CheckCircle2, ChevronRight, Clock3, Download, Globe2, GraduationCap, LockKeyhole, Mail, Menu, Play, Rocket, ShieldCheck, Sparkles, Star, Target, Users, X, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

type Course = {
  slug: string;
  title: string;
  description: string;
  category: string;
  level: string;
  duration: string;
  lessons: string[];
  lessonCount: number;
  accent: string;
  soft: string;
  rating: string;
  students: string;
  priceCents: number;
};

type Certificate = {
  certificateId: string;
  studentName: string;
  studentEmail: string;
  courseTitle: string;
  score: number;
  issuedAt: string;
};

const courseData: Course[] = [
  {
    slug: "digital-marketing-bilowga",
    title: "Digital Marketing Bilowga",
    description: "Baro sida loo dhiso presence online ah oo dadka saxda ah kuu keena.",
    category: "Ganacsi & Suuq-geyn",
    level: "Bilowga",
    duration: "3 saacadood",
    lessons: ["Aasaaska digital marketing", "Audience-kaaga faham", "Content qorshee", "Social media strategy", "Ads-ka si fudud u bilow", "Qorshahaaga 30 maalmood"],
    lessonCount: 6,
    accent: "#ee7e5f",
    soft: "#fff0e9",
    rating: "4.9",
    students: "2.4k",
    priceCents: 2500,
  },
  {
    slug: "computing-business",
    title: "Computing Skills for Business",
    description: "Baro computer skills-ka muhiimka u ah shaqo, ganacsi, iyo productivity.",
    category: "Technology",
    level: "Bilowga",
    duration: "4 saacadood",
    lessons: ["Computer basics", "Files iyo folders", "Word documents", "Spreadsheets", "Online safety", "Business workflow"],
    lessonCount: 7,
    accent: "#278a78",
    soft: "#e7f6f1",
    rating: "4.8",
    students: "1.8k",
    priceCents: 2500,
  },
  {
    slug: "accounting-financial-management",
    title: "Accounting & Financial Management",
    description: "Faham accounting basics, miisaaniyadda, iyo maamulka maaliyadda.",
    category: "Finance",
    level: "Dhexdhexaad",
    duration: "5 saacadood",
    lessons: ["Accounting basics", "Income iyo expenses", "Budget samee", "Cash flow", "Financial reports", "Management decisions"],
    lessonCount: 8,
    accent: "#7b61d7",
    soft: "#f0edff",
    rating: "4.9",
    students: "1.4k",
    priceCents: 3000,
  },
  {
    slug: "forex-trading",
    title: "Forex Trading",
    description: "Baro aasaaska suuqa Forex, risk management, iyo qorshe ganacsi oo masuul ah.",
    category: "Finance & Trading",
    level: "Bilowga",
    duration: "4 saacadood",
    lessons: ["Forex basics", "Currency pairs", "Charts akhri", "Risk management", "Trading plan", "Final practice"],
    lessonCount: 8,
    accent: "#d18b3f",
    soft: "#fff5df",
    rating: "4.8",
    students: "1.2k",
    priceCents: 4000,
  },
  {
    slug: "artificial-intelligence",
    title: "Artificial Intelligence",
    description: "Faham AI-ga casriga ah oo ku dabaq shaqada, waxbarashada, iyo ganacsiga.",
    category: "Technology",
    level: "Dhexdhexaad",
    duration: "5 saacadood",
    lessons: ["AI waa maxay?", "Prompt writing", "AI tools", "Automation", "Ethics & safety", "AI project"],
    lessonCount: 8,
    accent: "#6575d8",
    soft: "#eef0ff",
    rating: "4.9",
    students: "2.0k",
    priceCents: 3000,
  },
];

const quizOptions = [
  "Inaad sugto ilaa aad wax walba si fiican u barato",
  "Inaad si joogto ah u tijaabiso, barato, oo horumariso",
  "Inaad hal mar ku post-gareyso oo aad joojiso",
  "Inaad qof kale u dhiibto dhammaan content-kaaga",
];

function Logo() {
  return <div className="flex items-center gap-2.5"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#153f36] text-white shadow-[0_8px_20px_rgba(21,63,54,.18)]"><Sparkles size={18} strokeWidth={2.5} /></div><span className="text-xl font-black tracking-[-0.06em] text-[#143e35]">HORMAX1 ACADEMY</span></div>;
}

function CourseCard({ course, onStart }: { course: Course; onStart: (course: Course) => void }) {
  return <article className="group relative overflow-hidden rounded-[26px] border border-[#e6e2dc] bg-white p-5 shadow-[0_12px_35px_rgba(35,49,42,.06)] transition duration-200 hover:-translate-y-1 hover:shadow-[0_20px_45px_rgba(35,49,42,.12)]">
    <div className="mb-5 flex h-40 items-end justify-between overflow-hidden rounded-[20px] p-5" style={{ background: course.soft }}>
      <div><span className="rounded-full bg-white/80 px-3 py-1 text-[11px] font-bold uppercase tracking-[.13em] text-[#355348]">{course.category}</span><div className="mt-5 max-w-[190px] text-2xl font-black leading-[1.04] tracking-[-.06em] text-[#173f35]">{course.title}</div></div>
      <div className="relative h-20 w-20"><div className="absolute inset-0 rounded-full border-[10px] border-white/70" /><div className="absolute inset-0 rotate-[-35deg] rounded-full border-[10px] border-transparent" style={{ borderTopColor: course.accent, borderRightColor: course.accent }} /><div className="absolute inset-0 grid place-items-center text-xs font-black" style={{ color: course.accent }}>START</div></div>
    </div>
    <p className="min-h-[48px] text-sm leading-6 text-[#64736c]">{course.description}</p>
    <div className="mt-5 flex items-center justify-between border-t border-[#f0ece6] pt-4 text-xs font-semibold text-[#7b8982]"><span className="flex items-center gap-1.5"><Clock3 size={14} /> {course.duration}</span><span>{course.level}</span><span className="flex items-center gap-1"><Star size={13} fill="#f4b740" color="#f4b740" /> {course.rating}</span></div>
    <div className="mt-5 flex items-center justify-between"><span className="text-lg font-black text-[#173f35]">${(course.priceCents / 100).toFixed(2)}</span><button onClick={() => onStart(course)} className="flex items-center justify-center gap-2 rounded-xl bg-[#f4f1ec] px-4 py-3 text-sm font-extrabold text-[#173f35] transition hover:bg-[#173f35] hover:text-white">Enroll / Pay Now <ArrowRight size={16} /></button></div>
  </article>;
}

function LearningWorkspace({ course, student, onStudent, onCertificate }: { course: Course; student: { name: string; email: string } | null; onStudent: (student: { name: string; email: string }) => void; onCertificate: (certificate: Certificate) => void }) {
  const { user } = useAuth();
  const accessQuery = trpc.learning.hasAccess.useQuery({ courseSlug: course.slug }, { enabled: Boolean(user) });
  const [step, setStep] = useState(() => { try { return Number(localStorage.getItem(`learnsoo-progress-${course.slug}`) ?? 0); } catch { return 0; } });
  const [registered, setRegistered] = useState(Boolean(student));
  const [name, setName] = useState(student?.name ?? "");
  const [email, setEmail] = useState(student?.email ?? "");
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizDone, setQuizDone] = useState(false);
  const [wrong, setWrong] = useState(false);
  const certificateMutation = trpc.learning.issueCertificate.useMutation();
  const progressQuery = trpc.learning.getProgress.useQuery({ courseSlug: course.slug }, { enabled: Boolean(user) });
  const saveProgressMutation = trpc.learning.saveProgress.useMutation();
  const progress = Math.round((step / (course.lessons.length + 1)) * 100);
  const lessonTitle = course.lessons[step] ?? "Quiz-ka koorsada";

  useEffect(() => { if (student) { setRegistered(true); setName(student.name); setEmail(student.email); } }, [student]);
  useEffect(() => { try { localStorage.setItem(`learnsoo-progress-${course.slug}`, String(step)); } catch { /* preview fallback */ } }, [course.slug, step]);
  useEffect(() => { if (user && progressQuery.data && progressQuery.data.progress > progress) setStep(Math.round((progressQuery.data.progress / 100) * (course.lessons.length + 1))); }, [course.lessons.length, progress, progressQuery.data, user]);
  useEffect(() => { if (user) saveProgressMutation.mutate({ courseSlug: course.slug, progress }); }, [course.slug, progress, user]);

  const start = (event: FormEvent) => { event.preventDefault(); if (!name.trim() || !email.includes("@")) return; const value = { name: name.trim(), email: email.trim() }; onStudent(value); setRegistered(true); };
  const next = () => { setWrong(false); setSelectedAnswer(null); setStep((current) => Math.min(current + 1, course.lessons.length)); };
  const finishQuiz = async () => {
    if (selectedAnswer !== 1) { setWrong(true); return; }
    setQuizDone(true);
    const score = 96;
    try {
      const result = await certificateMutation.mutateAsync({ studentName: name, studentEmail: email, courseSlug: course.slug, courseTitle: course.title, score });
      onCertificate(result);
    } catch (error) {
      setQuizDone(false);
      window.alert(error instanceof Error ? error.message : "Certificate-ka lama samayn karo ilaa payment-ka la ansixiyo.");
    }
  };

  return <section id="learn" className="mx-auto max-w-7xl scroll-mt-24 px-5 pb-24 pt-10 md:px-8"><div className="mb-6 flex items-end justify-between gap-4"><div><p className="mb-2 text-xs font-black uppercase tracking-[.18em] text-[#ee7e5f]">Learning studio</p><h2 className="text-3xl font-black tracking-[-.06em] text-[#173f35]">{course.title}</h2></div><button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="rounded-full p-2 text-[#7b8982] hover:bg-white" aria-label="Close"><X size={19} /></button></div>
    <div className="grid gap-5 lg:grid-cols-[260px_1fr]">
      <aside className="rounded-[26px] border border-[#e6e2dc] bg-white p-4 shadow-[0_12px_35px_rgba(35,49,42,.06)]"><div className="mb-4 rounded-2xl bg-[#f7f5f0] p-4"><div className="mb-2 flex items-center justify-between text-xs font-bold text-[#7b8982]"><span>Horumarkaaga</span><span className="text-[#173f35]">{registered ? `${progress}%` : "0%"}</span></div><div className="h-2 overflow-hidden rounded-full bg-[#e7e4de]"><div className="h-full rounded-full bg-[#ee7e5f] transition-all duration-300" style={{ width: `${registered ? progress : 0}%` }} /></div></div><div className="space-y-1">{course.lessons.map((lesson, index) => <button key={lesson} disabled={!registered || index > step} onClick={() => setStep(index)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition ${index === step && registered ? "bg-[#173f35] font-bold text-white" : "text-[#627169] hover:bg-[#f7f5f0]"}`}><span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-black ${index < step ? "bg-[#d7f1e8] text-[#267862]" : index === step && registered ? "bg-[#ee7e5f] text-white" : "bg-[#efebe5] text-[#88948e]"}`}>{index < step ? <Check size={13} /> : index + 1}</span><span className="line-clamp-2">{lesson}</span></button>)}<button disabled={!registered || step < course.lessons.length} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm ${step === course.lessons.length ? "bg-[#fff0e9] font-bold text-[#c75f43]" : "text-[#9aa39e]"}`}><span className="grid h-6 w-6 place-items-center rounded-full bg-[#efebe5] text-[11px] font-black">Q</span>Quiz + Certificate</button></div></aside>
      <div className="min-h-[460px] rounded-[28px] border border-[#e6e2dc] bg-white p-6 shadow-[0_12px_35px_rgba(35,49,42,.06)] md:p-9">
        {!user || (accessQuery.data && !accessQuery.data.access) ? <div className="mx-auto max-w-xl py-12 text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#fff0e9] text-[#ee7e5f]"><LockKeyhole size={28} /></div><p className="mt-5 text-xs font-black uppercase tracking-[.16em] text-[#ee7e5f]">Course locked</p><h3 className="mt-2 text-3xl font-black tracking-[-.06em] text-[#173f35]">Bixi si aad u furto.</h3><p className="mt-3 leading-7 text-[#68766f]">{course.title} wuxuu leeyahay qiime gaar ah oo ah <strong>${(course.priceCents / 100).toFixed(2)}</strong>. Payment proof soo gudbi, admin-kuna markuu ansixiyo casharrada ayaa kuu furmaya.</p><a href="/payments" className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[#ee7e5f] px-5 py-3.5 text-sm font-black text-white">Enroll / Pay Now <ArrowRight size={16} /></a></div> : !registered ? <div className="mx-auto max-w-xl py-8"><div className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-[#fff0e9] text-[#ee7e5f]"><GraduationCap size={27} /></div><p className="mb-2 text-xs font-black uppercase tracking-[.16em] text-[#ee7e5f]">Tallaabada 1aad</p><h3 className="text-3xl font-black tracking-[-.06em] text-[#173f35]">Is diiwaangeli oo bilow.</h3><p className="mt-3 max-w-md leading-7 text-[#68766f]">Magacaaga waxaa si qurux badan loogu qori doonaa certificate-ka marka aad koorsada dhammayso.</p><form onSubmit={start} className="mt-7 space-y-4"><label className="block text-sm font-bold text-[#314a40]">Magacaaga oo buuxa<input value={name} onChange={(event) => setName(event.target.value)} className="mt-2 w-full rounded-xl border border-[#ddd9d1] bg-[#fcfbf8] px-4 py-3 outline-none transition focus:border-[#ee7e5f] focus:ring-4 focus:ring-[#ee7e5f]/10" placeholder="Tusaale: Ayaan Cabdi" required /></label><label className="block text-sm font-bold text-[#314a40]">Email-kaaga<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="mt-2 w-full rounded-xl border border-[#ddd9d1] bg-[#fcfbf8] px-4 py-3 outline-none transition focus:border-[#ee7e5f] focus:ring-4 focus:ring-[#ee7e5f]/10" placeholder="ayaan@email.com" required /></label><button className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#173f35] py-3.5 text-sm font-black text-white transition hover:bg-[#23594b]">Sii wad casharka <ArrowRight size={16} /></button></form></div> : step < course.lessons.length ? <div className="flex h-full flex-col"><div className="mb-8 flex items-center justify-between"><div><p className="mb-2 text-xs font-black uppercase tracking-[.16em] text-[#ee7e5f]">Cashar {step + 1} / {course.lessons.length}</p><h3 className="text-3xl font-black tracking-[-.06em] text-[#173f35]">{lessonTitle}</h3></div><div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e7f6f1] text-[#278a78]"><Play size={20} fill="currentColor" /></div></div><div className="grid gap-5 md:grid-cols-[1.25fr_.75fr]"><div className="rounded-2xl bg-[#173f35] p-6 text-white"><p className="text-sm leading-7 text-white/75">Casharkan waxaad ku baranaysaa fikradda ugu muhiimsan ee {course.title.toLowerCase()}. Akhri, ka fikir tusaalaha, kadibna ku tijaabi hawsha yar ee hoose.</p><div className="mt-7 rounded-2xl bg-white/10 p-5"><div className="mb-3 flex items-center gap-2 text-sm font-bold"><Target size={16} className="text-[#f5a37f]" /> Hawshaada maanta</div><p className="text-sm leading-6 text-white/80">Qor hal fikrad oo aad maanta ku dabaqi karto shaqadaada ama mashruucaaga gaarka ah.</p></div></div><div className="rounded-2xl border border-[#eae5dc] bg-[#fcfbf8] p-6"><div className="mb-4 flex items-center gap-2 text-sm font-black text-[#173f35]"><Zap size={16} className="text-[#ee7e5f]" /> Quick note</div><p className="text-sm leading-6 text-[#68766f]">Barashadu ma aha in wax walba hal mar la xafido. Waa in fikradaha yaryar si joogto ah loo isticmaalo.</p><div className="mt-7 flex items-center gap-2 text-xs font-bold text-[#278a78]"><CheckCircle2 size={16} /> 5 daqiiqo oo akhris ah</div></div></div><div className="mt-auto flex justify-end pt-8"><button onClick={next} className="flex items-center gap-2 rounded-xl bg-[#ee7e5f] px-5 py-3 text-sm font-black text-white transition hover:bg-[#d96e50]">Casharka xiga <ChevronRight size={16} /></button></div></div> : <div className="mx-auto max-w-2xl py-3"><div className="mb-6 flex items-center gap-3"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#fff0e9] text-[#ee7e5f]"><Award size={24} /></div><div><p className="text-xs font-black uppercase tracking-[.16em] text-[#ee7e5f]">Final check</p><h3 className="text-3xl font-black tracking-[-.06em] text-[#173f35]">Hal su'aal oo keliya.</h3></div></div><p className="text-[#68766f]">Maxaa kaa caawinaya inaad xirfad cusub si dhab ah u barato?</p><div className="mt-6 space-y-3">{quizOptions.map((option, index) => <button key={option} onClick={() => setSelectedAnswer(index)} className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left text-sm leading-6 transition ${selectedAnswer === index ? "border-[#ee7e5f] bg-[#fff0e9] text-[#173f35]" : "border-[#e6e2dc] hover:border-[#cfc8bc]"}`}><span className={`mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-black ${selectedAnswer === index ? "bg-[#ee7e5f] text-white" : "bg-[#f0ede7] text-[#7b8982]"}`}>{String.fromCharCode(65 + index)}</span>{option}</button>)}</div>{wrong && <p className="mt-4 text-sm font-bold text-[#c75f43]">Isku day mar kale — jawaabta saxda ahi waa inaad si joogto ah u tijaabiso oo u horumariso.</p>}<button disabled={selectedAnswer === null || quizDone} onClick={finishQuiz} className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-[#173f35] py-3.5 text-sm font-black text-white transition enabled:hover:bg-[#23594b] disabled:cursor-not-allowed disabled:opacity-40">{quizDone ? "Certificate-ka waa la sameeyay" : "Dhameystir oo hel certificate"} <Award size={17} /></button></div>}
      </div>
    </div>
  </section>;
}

function CertificateSuccess({ certificate, onView }: { certificate: Certificate; onView: () => void }) {
  return <section className="mx-auto max-w-7xl px-5 pb-24 md:px-8"><div className="overflow-hidden rounded-[30px] bg-[#173f35] p-7 text-white shadow-[0_18px_50px_rgba(23,63,53,.18)] md:p-10"><div className="grid items-center gap-8 md:grid-cols-[1fr_auto]"><div><div className="mb-4 flex items-center gap-2 text-[#f7b095]"><CheckCircle2 size={20} /><span className="text-xs font-black uppercase tracking-[.16em]">Hambalyo {certificate.studentName.split(" ")[0]}</span></div><h2 className="max-w-2xl text-3xl font-black tracking-[-.06em] md:text-4xl">Waad dhammaysay. Certificate-kaaga waa diyaar.</h2><p className="mt-4 max-w-xl text-sm leading-7 text-white/70">Shahaadada <strong className="text-white">{certificate.courseTitle}</strong> waxay diyaar u tahay in la daawado, la soo dejisto, ama link ahaan email lagu diro.</p><div className="mt-6 flex flex-wrap gap-3"><button onClick={onView} className="flex items-center gap-2 rounded-xl bg-[#ee7e5f] px-5 py-3 text-sm font-black text-white hover:bg-[#d96e50]"><Award size={17} /> Daawo certificate</button><span className="flex items-center gap-2 rounded-xl border border-white/15 px-4 py-3 text-xs font-bold text-white/70"><Mail size={15} /> Link email-ready</span></div></div><div className="grid h-36 w-36 place-items-center rounded-full border border-white/15 bg-white/5"><div className="grid h-24 w-24 place-items-center rounded-full border-2 border-[#f7b095] text-center"><div><div className="text-3xl font-black">{certificate.score}%</div><div className="text-[10px] font-bold uppercase tracking-widest text-white/60">score</div></div></div></div></div></div></section>;
}

export default function Home() {
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [student, setStudent] = useState<{ name: string; email: string } | null>(() => { try { const saved = localStorage.getItem("learnsoo-student"); return saved ? JSON.parse(saved) : null; } catch { return null; } });
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const coursesQuery = trpc.learning.courses.useQuery();
  const displayCourses = useMemo(() => {
    const rows = coursesQuery.data as Array<Partial<Course> & { slug: string; title: string; lessonCount?: number; priceCents?: number }> | undefined;
    if (!rows?.length) return courseData;
    return rows.map((row, index) => {
      const fallback = courseData.find((course) => course.slug === row.slug) ?? courseData[index % courseData.length];
      const lessonCount = row.lessonCount ?? fallback.lessonCount;
      return {
        ...fallback,
        ...row,
        lessons: row.lessons ?? fallback.lessons.slice(0, lessonCount).concat(Array.from({ length: Math.max(0, lessonCount - fallback.lessons.length) }, (_, lessonIndex) => `Casharka ${fallback.lessons.length + lessonIndex + 1}`)),
        accent: row.accent ?? fallback.accent,
        soft: row.soft ?? fallback.soft,
        rating: row.rating ?? fallback.rating,
        students: row.students ?? fallback.students,
        priceCents: row.priceCents ?? fallback.priceCents,
      } as Course;
    });
  }, [coursesQuery.data]);

  const startCourse = (course: Course) => { setActiveCourse(course); setCertificate(null); setTimeout(() => document.getElementById("learn")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60); };
  const showCertificate = (value: Certificate) => { localStorage.setItem(`learnsoo-certificate-${value.certificateId}`, JSON.stringify(value)); setCertificate(value); setTimeout(() => document.getElementById("certificate-success")?.scrollIntoView({ behavior: "smooth", block: "center" }), 60); };

  return <div className="min-h-screen overflow-x-hidden bg-[#fbfaf7] text-[#173f35]">
    <header className="sticky top-0 z-30 border-b border-[#e9e5de]/80 bg-[#fbfaf7]/90 backdrop-blur-xl"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-8"><Logo /><nav className="hidden items-center gap-8 text-sm font-bold text-[#708078] md:flex"><a href="#courses" className="transition hover:text-[#173f35]">Koorsooyin</a><a href="#how" className="transition hover:text-[#173f35]">Sida ay u shaqeyso</a><a href="/verify" className="transition hover:text-[#173f35]">Hubi certificate</a><a href="/ai-business-quiz" className="transition hover:text-[#173f35]">AI Business Quiz</a></nav><div className="hidden items-center gap-3 md:flex"><button onClick={() => startLogin()} className="rounded-xl px-4 py-2.5 text-sm font-bold text-[#537067] hover:bg-white">Soo gal</button><button onClick={() => document.getElementById("courses")?.scrollIntoView({ behavior: "smooth" })} className="rounded-xl bg-[#173f35] px-4 py-2.5 text-sm font-black text-white shadow-lg shadow-[#173f35]/15 hover:bg-[#23594b]">Bilow bilaash</button></div><button onClick={() => setMenuOpen(!menuOpen)} className="rounded-lg p-2 md:hidden" aria-label="Menu"><Menu size={21} /></button></div>{menuOpen && <div className="border-t border-[#e9e5de] bg-[#fbfaf7] px-5 py-4 md:hidden"><div className="flex flex-col gap-3 text-sm font-bold text-[#537067]"><a href="#courses" onClick={() => setMenuOpen(false)}>Koorsooyin</a><a href="#how" onClick={() => setMenuOpen(false)}>Sida ay u shaqeyso</a><a href="/verify" onClick={() => setMenuOpen(false)}>Hubi certificate</a><a href="/ai-business-quiz" onClick={() => setMenuOpen(false)}>AI Business Quiz</a></div></div>}</header>
    <main>
      <section className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 pb-20 pt-16 md:grid-cols-[1.05fr_.95fr] md:px-8 md:pb-28 md:pt-24"><div className="absolute left-[-100px] top-[-100px] -z-0 h-72 w-72 rounded-full bg-[#f6c3a5]/30 blur-3xl" /><div className="relative z-10"><div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#f1d8cb] bg-[#fff4ee] px-3.5 py-2 text-xs font-black uppercase tracking-[.13em] text-[#d36c50]"><Sparkles size={14} /> Learning-kaaga, si fudud</div><h1 className="max-w-2xl text-5xl font-black leading-[.98] tracking-[-.075em] text-[#173f35] md:text-7xl">Xirfaddaada kor u qaad.<br /><span className="text-[#ee7e5f]">Tallaabo kasta</span> waa guul.</h1><p className="mt-6 max-w-xl text-base leading-8 text-[#69766f] md:text-lg">HORMAX1 ACADEMY waa meel waxbarasho oo kuu dhisan — casharro gaagaaban, quiz-yo cad, iyo certificate aad ku faani karto.</p><div className="mt-8 flex flex-wrap items-center gap-3"><button onClick={() => document.getElementById("courses")?.scrollIntoView({ behavior: "smooth" })} className="flex items-center gap-2 rounded-xl bg-[#ee7e5f] px-5 py-3.5 text-sm font-black text-white shadow-[0_12px_25px_rgba(238,126,95,.2)] transition hover:-translate-y-0.5 hover:bg-[#d96e50]">Bilow barashada <ArrowRight size={17} /></button><a href="#how" className="flex items-center gap-2 rounded-xl border border-[#dcd8d0] bg-white px-5 py-3.5 text-sm font-black text-[#365449] hover:border-[#bdb6a9]">Sida ay u shaqeyso <Play size={15} fill="currentColor" /></a></div><div className="mt-10 flex items-center gap-6 text-sm"><div className="flex -space-x-2"><div className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#fbfaf7] bg-[#f4b798] text-[10px] font-black">AM</div><div className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#fbfaf7] bg-[#b9d4c8] text-[10px] font-black">SA</div><div className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#fbfaf7] bg-[#c9b8e9] text-[10px] font-black">FN</div></div><div><div className="flex items-center gap-1 font-black text-[#173f35]"><Star size={14} fill="#f4b740" color="#f4b740" /> 4.9/5</div><div className="text-xs text-[#7c8982]">Ardaydu way jecel yihiin</div></div></div></div><div className="relative z-10"><div className="relative mx-auto max-w-[470px] rounded-[34px] bg-[#dff1eb] p-4 shadow-[0_25px_55px_rgba(48,92,75,.13)] md:rotate-[2deg]"><div className="rounded-[26px] bg-white p-5 md:p-6"><div className="mb-5 flex items-center justify-between"><div><div className="text-[11px] font-black uppercase tracking-[.14em] text-[#8a9890]">Your learning space</div><div className="mt-1 text-lg font-black tracking-[-.04em]">Subax wanaagsan, Ayaan <span>✦</span></div></div><div className="grid h-9 w-9 place-items-center rounded-full bg-[#fbe2d5] text-xs font-black text-[#b96649]">AC</div></div><div className="rounded-2xl bg-[#173f35] p-5 text-white"><div className="flex items-start justify-between"><div><div className="text-xs text-white/60">Horumarkaaga maanta</div><div className="mt-2 text-3xl font-black">68%</div></div><div className="grid h-12 w-12 place-items-center rounded-full border-4 border-[#ee7e5f] border-r-white/10 text-[10px] font-black">7/10</div></div><div className="mt-5 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[68%] rounded-full bg-[#ee7e5f]" /></div><div className="mt-3 flex justify-between text-[11px] text-white/55"><span>4 cashar ayaa kuu haray</span><span>Socodsii →</span></div></div><div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-2xl bg-[#fff3ed] p-4"><div className="mb-5 grid h-8 w-8 place-items-center rounded-lg bg-white text-[#ee7e5f]"><BookOpen size={16} /></div><div className="text-xs text-[#8a9890]">Casharro la dhammaystay</div><div className="mt-1 text-xl font-black">24</div></div><div className="rounded-2xl bg-[#eef8f4] p-4"><div className="mb-5 grid h-8 w-8 place-items-center rounded-lg bg-white text-[#278a78]"><Award size={16} /></div><div className="text-xs text-[#8a9890]">Certificates</div><div className="mt-1 text-xl font-black">03</div></div></div><div className="mt-5 flex items-center gap-3 rounded-2xl border border-[#eeeae4] p-3"><div className="grid h-11 w-11 place-items-center rounded-xl bg-[#f0edff] text-[#7b61d7]"><BarChart3 size={20} /></div><div className="flex-1"><div className="text-sm font-black">Digital Marketing</div><div className="text-xs text-[#88948e]">Casharka 4aad • 18 daqiiqo</div></div><ChevronRight size={16} className="text-[#a0aaa3]" /></div></div><div className="absolute -right-6 top-12 hidden items-center gap-2 rounded-2xl border border-white bg-white px-3 py-2.5 text-xs font-black text-[#173f35] shadow-[0_14px_30px_rgba(35,49,42,.12)] md:flex"><span className="grid h-6 w-6 place-items-center rounded-full bg-[#e2f6ed] text-[#278a78]"><Check size={14} /></span> You are on a roll!</div><div className="absolute -bottom-5 -left-7 hidden items-center gap-2 rounded-2xl border border-white bg-white px-3 py-2.5 text-xs font-black text-[#173f35] shadow-[0_14px_30px_rgba(35,49,42,.12)] md:flex"><span className="grid h-6 w-6 place-items-center rounded-full bg-[#fff1e9] text-[#ee7e5f]"><Rocket size={14} /></span> Keep going</div></div></div></section>
      <section className="border-y border-[#eeeae3] bg-white/60"><div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-5 py-7 md:grid-cols-4 md:px-8"><div><div className="text-2xl font-black tracking-[-.06em] text-[#173f35]">12k<span className="text-[#ee7e5f]">+</span></div><div className="mt-1 text-xs font-bold text-[#89958f]">Arday firfircoon</div></div><div><div className="text-2xl font-black tracking-[-.06em] text-[#173f35]">48<span className="text-[#ee7e5f]">+</span></div><div className="mt-1 text-xs font-bold text-[#89958f]">Koorsooyin la diyaariyey</div></div><div><div className="text-2xl font-black tracking-[-.06em] text-[#173f35]">94<span className="text-[#ee7e5f]">%</span></div><div className="mt-1 text-xs font-bold text-[#89958f]">Dhameystir wanaagsan</div></div><div><div className="text-2xl font-black tracking-[-.06em] text-[#173f35]">4.9<span className="text-[#ee7e5f]">/5</span></div><div className="mt-1 text-xs font-bold text-[#89958f]">Celcelis rating</div></div></div></section>
      <section id="courses" className="mx-auto max-w-7xl scroll-mt-24 px-5 py-20 md:px-8 md:py-28"><div className="mb-10 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="mb-3 text-xs font-black uppercase tracking-[.18em] text-[#ee7e5f]">Koorsooyin la doortay</p><h2 className="max-w-xl text-4xl font-black tracking-[-.07em] text-[#173f35] md:text-5xl">Wax baro. Ku dhaqan. Horumar samee.</h2></div><p className="max-w-sm text-sm leading-6 text-[#738078]">Cashar kasta waxaa loo kala dhigay tallaabooyin yar-yar si aad u barato adigoon lumin xiisaha.</p></div><div className="grid gap-5 md:grid-cols-3">{displayCourses.map((course) => <CourseCard key={course.slug} course={course} onStart={startCourse} />)}</div></section>
      <section id="how" className="bg-[#173f35] px-5 py-20 text-white md:px-8 md:py-24"><div className="mx-auto max-w-7xl"><div className="grid gap-12 md:grid-cols-[.8fr_1.2fr] md:items-end"><div><p className="mb-3 text-xs font-black uppercase tracking-[.18em] text-[#f7b095]">Sida ay u shaqeyso</p><h2 className="max-w-md text-4xl font-black tracking-[-.07em] md:text-5xl">Waxbarasho fudud oo natiijo leh.</h2></div><p className="max-w-lg text-sm leading-7 text-white/65">Wax walba waxaa loo dhisay hal ujeeddo: inaad maanta bilowdo, aad berri wax isticmaasho, oo aad dhowaan wax ku muujiso.</p></div><div className="mt-12 grid gap-4 md:grid-cols-3"><div className="rounded-[24px] border border-white/10 bg-white/5 p-6"><div className="mb-12 flex items-center justify-between"><span className="text-sm font-black text-[#f7b095]">01</span><BookOpen size={21} className="text-white/60" /></div><h3 className="text-xl font-black">Dooro cashar</h3><p className="mt-3 text-sm leading-6 text-white/60">Koorso kasta wuxuu leeyahay roadmap cad, si aad u ogaato tallaabada xigta.</p></div><div className="rounded-[24px] border border-white/10 bg-white/5 p-6"><div className="mb-12 flex items-center justify-between"><span className="text-sm font-black text-[#f7b095]">02</span><Target size={21} className="text-white/60" /></div><h3 className="text-xl font-black">Ku celceli + quiz</h3><p className="mt-3 text-sm leading-6 text-white/60">Waxaad cashar kasta ka dib helaysaa su'aalo kooban oo xoojinaya fahamkaaga.</p></div><div id="certificate" className="rounded-[24px] border border-white/10 bg-white/5 p-6"><div className="mb-12 flex items-center justify-between"><span className="text-sm font-black text-[#f7b095]">03</span><Award size={21} className="text-white/60" /></div><h3 className="text-xl font-black">Hel certificate</h3><p className="mt-3 text-sm leading-6 text-white/60">Markaad dhammayso, magacaaga ku hel certificate digital ah oo link leh.</p></div></div></div></section>
      <section className="mx-auto max-w-7xl px-5 py-20 md:px-8"><div className="rounded-[30px] border border-[#e9e4dc] bg-[#fff3ed] p-7 md:p-12"><div className="grid items-center gap-10 md:grid-cols-[1fr_auto]"><div><div className="mb-4 flex items-center gap-2 text-xs font-black uppercase tracking-[.16em] text-[#d36c50]"><Users size={16} /> Bulshada HORMAX1 ACADEMY</div><h2 className="max-w-xl text-3xl font-black tracking-[-.06em] text-[#173f35] md:text-4xl">Adiga oo baranaya, ma tihid kaligaa.</h2><p className="mt-4 max-w-xl text-sm leading-7 text-[#68766f]">Ku biir ardayda kale ee xirfadaha cusub maalin kasta baranaya — si tartiib ah, si joogto ah, si muuqata.</p></div><button onClick={() => document.getElementById("courses")?.scrollIntoView({ behavior: "smooth" })} className="flex items-center justify-center gap-2 rounded-xl bg-[#173f35] px-5 py-3.5 text-sm font-black text-white hover:bg-[#23594b]">Eeg koorsooyinka <ArrowRight size={16} /></button></div></div></section>
      {activeCourse && !certificate && <LearningWorkspace course={activeCourse} student={student} onStudent={(value) => { setStudent(value); try { localStorage.setItem("learnsoo-student", JSON.stringify(value)); } catch { /* preview fallback */ } }} onCertificate={showCertificate} />}
      {certificate && <div id="certificate-success"><CertificateSuccess certificate={certificate} onView={() => { localStorage.setItem(`learnsoo-certificate-${certificate.certificateId}`, JSON.stringify(certificate)); window.location.href = `/certificate/${certificate.certificateId}`; }} /></div>}
    </main>
    <footer className="border-t border-[#e9e5de] bg-white/60"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-5 px-5 py-8 text-sm text-[#7c8982] md:flex-row md:items-center md:px-8"><Logo /><div>© 2026 HORMAX1 ACADEMY · Waxbarasho qof walba u furan</div><div className="flex items-center gap-4"><Globe2 size={16} /> Somali-first learning</div></div></footer>
  </div>;
}

export function CertificatePage() {
  const certificateId = window.location.pathname.split("/").pop() ?? "demo";
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  useEffect(() => { const saved = localStorage.getItem(`learnsoo-certificate-${certificateId}`); if (saved) setCertificate(JSON.parse(saved)); }, [certificateId]);
  const verified = trpc.learning.verifyCertificate.useQuery({ certificateId }, { enabled: Boolean(certificateId) });
  const value = certificate ?? (verified.data ? { ...verified.data, studentEmail: "" } : null);
  if (!value) return <div className="grid min-h-screen place-items-center bg-[#f7f5f0] p-5 text-center"><div><ShieldCheck className="mx-auto text-[#ee7e5f]" size={34} /><h1 className="mt-4 text-2xl font-black">Certificate lama helin</h1><p className="mt-2 text-sm text-[#718078]">Hubi Certificate ID-ga ama fur bogga verification-ka.</p><a href="/verify" className="mt-5 inline-flex rounded-xl bg-[#173f35] px-4 py-3 text-sm font-black text-white">Hubi certificate</a></div></div>;
  return <div className="min-h-screen bg-[#f3eee7] px-4 py-8 text-[#173f35] md:px-8 md:py-14"><div className="mx-auto max-w-5xl"><div className="mb-7 flex items-center justify-between"><a href="/" className="flex items-center gap-2 text-sm font-black text-[#173f35]"><span className="grid h-8 w-8 place-items-center rounded-lg bg-[#173f35] text-white"><Sparkles size={15} /></span> HORMAX1 ACADEMY</a><button onClick={() => window.print()} className="flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-black text-[#173f35] shadow-sm"><Download size={16} /> Download / Print</button></div><div className="relative overflow-hidden rounded-[8px] border-[12px] border-[#173f35] bg-[#fffdf9] p-4 shadow-[0_22px_70px_rgba(44,56,44,.16)] md:p-8"><div className="border border-[#d6b16c] p-8 text-center md:p-16"><div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#173f35] text-white"><Award size={31} /></div><div className="mt-6 text-xs font-black uppercase tracking-[.35em] text-[#a27b37]">HORMAX1 ACADEMY</div><h1 className="mt-6 font-serif text-4xl font-bold tracking-[-.04em] text-[#173f35] md:text-6xl">Shahaado Guul</h1><p className="mx-auto mt-6 max-w-xl text-sm leading-7 text-[#68766f]">Waxaa si sharaf leh loo guddoonsiiyey</p><div className="mt-3 font-serif text-3xl font-bold italic text-[#ee7e5f] md:text-5xl">{value.studentName}</div><p className="mx-auto mt-6 max-w-xl text-sm leading-7 text-[#68766f]">Markii uu/ay si guul leh u dhammaystay koorsada</p><div className="mt-3 text-2xl font-black text-[#173f35] md:text-3xl">{value.courseTitle}</div><div className="mx-auto mt-12 grid max-w-lg grid-cols-2 gap-8 border-t border-[#e7ddca] pt-6 text-left text-xs text-[#7e887d]"><div><div className="font-black uppercase tracking-widest text-[#a27b37]">Issued date</div><div className="mt-2 font-bold text-[#173f35]">{new Date(value.issuedAt).toLocaleDateString()}</div></div><div className="text-right"><div className="font-black uppercase tracking-widest text-[#a27b37]">Certificate ID</div><div className="mt-2 font-bold text-[#173f35]">{value.certificateId}</div></div></div></div></div></div><div className="mx-auto mt-6 flex max-w-2xl items-center justify-center gap-2 text-center text-xs text-[#7f8a81]"><Mail size={14} /> Link-kan wuxuu diyaar u yahay in email loogu diro ardayga marka email service la xiro.</div></div>;
}
