import { useState } from "react";
import { ArrowLeft, DollarSign, Save, ShieldCheck } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

const money = (cents: number) => (cents / 100).toFixed(2);
export default function PricingAdmin() {
  const { user, loading } = useAuth();
  const pricing = trpc.learning.coursePricing.useQuery();
  const save = trpc.admin.saveCoursePricing.useMutation({ onSuccess: () => pricing.refetch() });
  if (loading) return <div className="grid min-h-screen place-items-center bg-[#f7f5f0]">Loading…</div>;
  if (!user) return <Gate login />;
  if (user.role !== "admin") return <Gate />;
  return <div className="min-h-screen bg-[#f7f5f0] text-[#173f35]"><header className="border-b border-[#e8e3db] bg-white"><div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4"><a href="/admin" className="flex items-center gap-2 text-sm font-black"><ArrowLeft size={15} /> Admin dashboard</a><a href="/" className="text-sm font-bold text-[#68776f]">Website-ka</a></div></header><main className="mx-auto max-w-5xl px-5 py-8"><p className="text-xs font-black uppercase tracking-[.18em] text-[#ee7e5f]">Course pricing</p><h1 className="mt-2 text-3xl font-black tracking-[-.06em]">Qiimaha koorsooyinka.</h1><p className="mt-2 max-w-xl text-sm leading-6 text-[#718078]">Koorso kasta qiimaheeda si gaar ah u deji. Isbeddelka wuxuu saameynayaa payment page-ka cusub.</p><div className="mt-6 space-y-3">{pricing.data?.map((course) => <PriceRow key={course.slug} course={course} onSave={(priceCents, isPaid, active) => save.mutate({ slug: course.slug, title: course.title, priceCents, isPaid, active })} />)}</div></main></div>;
}
function PriceRow({ course, onSave }: { course: { slug: string; title: string; priceCents: number; isPaid?: number; active?: number }; onSave: (priceCents: number, isPaid: number, active: number) => void }) {
  const [price, setPrice] = useState(money(course.priceCents));
  const [paid, setPaid] = useState(course.isPaid !== 0);
  const [active, setActive] = useState(course.active !== 0);
  return <div className="grid gap-4 rounded-2xl border border-[#e8e3db] bg-white p-5 md:grid-cols-[1fr_150px_130px_auto] md:items-center"><div><div className="text-sm font-black">{course.title}</div><div className="mt-1 text-xs text-[#89958e]">{course.slug}</div></div><label className="text-xs font-bold text-[#718078]">Price ($)<div className="mt-1 flex items-center rounded-xl border border-[#ddd8cf] px-3"><DollarSign size={14} /><input value={price} onChange={(event) => setPrice(event.target.value)} className="w-full bg-transparent py-2 text-sm font-black outline-none" /></div></label><div className="space-y-2 text-xs font-bold"><label className="flex items-center gap-2"><input type="checkbox" checked={paid} onChange={(event) => setPaid(event.target.checked)} /> Paid</label><label className="flex items-center gap-2"><input type="checkbox" checked={active} onChange={(event) => setActive(event.target.checked)} /> Active</label></div><button onClick={() => onSave(Math.round(Number(price) * 100), paid ? 1 : 0, active ? 1 : 0)} className="flex items-center justify-center gap-2 rounded-xl bg-[#173f35] px-4 py-3 text-xs font-black text-white"><Save size={14} /> Save</button></div>;
}
function Gate({ login = false }: { login?: boolean }) { return <div className="grid min-h-screen place-items-center bg-[#f7f5f0] p-5"><div className="rounded-3xl border border-[#e8e3db] bg-white p-8 text-center"><ShieldCheck className="mx-auto text-[#ee7e5f]" size={30} /><h1 className="mt-4 text-2xl font-black">Admin access required</h1><p className="mt-2 text-sm text-[#718078]">{login ? "Soo gal si aad u maamusho qiimaha." : "Account-kan ma laha admin access."}</p>{login ? <button onClick={() => startLogin()} className="mt-5 rounded-xl bg-[#173f35] px-4 py-3 text-sm font-black text-white">Soo gal</button> : <a href="/" className="mt-5 inline-flex rounded-xl bg-[#173f35] px-4 py-3 text-sm font-black text-white">Website-ka</a>}</div></div>; }
